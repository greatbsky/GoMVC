/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'it', {
	'move': 'Fare clic e trascinare per spostare',
	'label': 'Widget %1'
} );
